To generate the documentation run:
phpdoc -o HTML:frames:earthli --ignore protected/tests/php-webdriver/ -d "full\path\to\project" -t phpdoc -q -ti "MySurvey Application" 